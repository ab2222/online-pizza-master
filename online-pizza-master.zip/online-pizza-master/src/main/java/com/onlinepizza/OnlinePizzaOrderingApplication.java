package com.onlinepizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePizzaOrderingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePizzaOrderingApplication.class, args);
	}

}
